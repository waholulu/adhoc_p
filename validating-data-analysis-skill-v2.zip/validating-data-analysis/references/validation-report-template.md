# Validation Report Template

Verdict: Usable / Usable with caveats / Not usable yet
Risk level: Exploratory / Business reporting / High stakes
Confidence: Low / Medium / High

## What was validated

- Business question:
- Output reviewed:
- Unit of analysis:
- Data sources:
- Date range:
- Metric definition:
- Validation evidence available:
- Validation evidence missing:

## Evidence summary

| Area | Status | Evidence | Severity | Action |
|---|---|---|---|---|
| Source freshness | | | | |
| Cohort | | | | |
| Grain | | | | |
| Joins | | | | |
| Numerator | | | | |
| Denominator | | | | |
| Date logic | | | | |
| Missingness | | | | |
| Sample trace | | | | |
| Reconciliation | | | | |
| Sensitivity | | | | |
| Golden dataset | | | | |
| Independent reproduction | | | | |

## Blockers

- Blocker:

## Warnings

- Warning:

## Recommended next actions

1. 
2. 
3. 

## Sign-off criteria

- Criterion:
