# pandas Validation Snippets

Use these snippets to validate pandas outputs and intermediate DataFrames.

## Profile a DataFrame

```python
profile = {
    "rows": len(df),
    "distinct_members": df["member_id"].nunique(dropna=True),
    "min_index_date": df["index_date"].min(),
    "max_index_date": df["index_date"].max(),
}
print(profile)
```

## Missingness summary

```python
important_cols = ["member_id", "index_date", "outcome_flag"]
missing = df[important_cols].isna().sum().sort_values(ascending=False)
print(missing)
```

## Duplicate business keys

```python
dups = (
    df.groupby("business_key")
      .size()
      .reset_index(name="rows")
      .query("rows > 1")
      .sort_values("rows", ascending=False)
)
print(dups.head(100))
```

## Before and after join comparison

```python
def profile_join_step(name, frame, key="business_key", amount_col="amount"):
    return {
        "step": name,
        "rows": len(frame),
        "distinct_keys": frame[key].nunique(dropna=True),
        "amount": frame[amount_col].sum() if amount_col in frame.columns else None,
    }

print(profile_join_step("before", before_df))
print(profile_join_step("after", after_df))
```

## Numerator and denominator

```python
denominator = len(df)
numerator = (df["outcome_flag"] == 1).sum()
rate = numerator / denominator if denominator else None
print({"denominator": denominator, "numerator": numerator, "rate": rate})
```

## Boundary date check

```python
df = df.copy()
df["days_from_index"] = (df["event_date"] - df["index_date"]).dt.days
boundary = (
    df.groupby("days_from_index")
      .agg(rows=("days_from_index", "size"), included_rows=("included_flag", "sum"))
      .reset_index()
      .sort_values("days_from_index")
)
print(boundary)
```
