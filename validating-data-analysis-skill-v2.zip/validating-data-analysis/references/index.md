# Reference Index

Open these files only when needed.

| Need | Open this file |
|---|---|
| Define the analysis before validation | `analysis-contract-template.md` |
| Produce a formal validation output | `validation-report-template.md` |
| Build known-answer test data | `golden-dataset-guide.md` |
| Write BigQuery checks | `bigquery-validation-snippets.md` |
| Write pandas checks | `pandas-validation-snippets.md` |
| Validate healthcare claims, enrollment, readmission, HHS, SNF, authorization, or cost analyses | `healthcare-claims-checklist.md` |

General order of use:

1. Start with the analysis contract.
2. Run or request source, grain, denominator, join, date, and sample checks.
3. Fill the validation report.
4. For recurring or high-stakes work, add golden dataset and independent reproduction evidence.
