# BigQuery Validation Snippets

Replace placeholder names before running. These snippets validate outputs and intermediate artifacts. They are not meant to be a full reimplementation.

## Profile a table

```sql
SELECT
  COUNT(*) AS row_count,
  COUNT(DISTINCT member_id) AS distinct_members,
  MIN(index_date) AS min_index_date,
  MAX(index_date) AS max_index_date
FROM `project.dataset.table`;
```

## Check missingness

```sql
SELECT
  COUNT(*) AS row_count,
  COUNTIF(member_id IS NULL) AS missing_member_id,
  COUNTIF(index_date IS NULL) AS missing_index_date,
  COUNTIF(outcome_flag IS NULL) AS missing_outcome_flag
FROM `project.dataset.table`;
```

## Check duplicate business keys

```sql
SELECT
  business_key,
  COUNT(*) AS rows
FROM `project.dataset.table`
GROUP BY business_key
HAVING COUNT(*) > 1
ORDER BY rows DESC
LIMIT 100;
```

## Check one-to-many join risk on the right table

```sql
SELECT
  join_key,
  COUNT(*) AS matches
FROM `project.dataset.right_table`
GROUP BY join_key
HAVING COUNT(*) > 1
ORDER BY matches DESC
LIMIT 100;
```

## Compare before and after totals

```sql
SELECT
  'before' AS step,
  COUNT(*) AS rows,
  COUNT(DISTINCT business_key) AS distinct_keys,
  SUM(amount) AS amount
FROM `project.dataset.before_table`
UNION ALL
SELECT
  'after' AS step,
  COUNT(*) AS rows,
  COUNT(DISTINCT business_key) AS distinct_keys,
  SUM(amount) AS amount
FROM `project.dataset.after_table`;
```

## Numerator and denominator

```sql
SELECT
  COUNT(*) AS denominator,
  COUNTIF(outcome_flag = 1) AS numerator,
  SAFE_DIVIDE(COUNTIF(outcome_flag = 1), COUNT(*)) AS rate
FROM `project.dataset.final_table`;
```

## Boundary date check

```sql
SELECT
  DATE_DIFF(event_date, index_date, DAY) AS days_from_index,
  COUNT(*) AS rows,
  COUNTIF(included_flag = 1) AS included_rows
FROM `project.dataset.final_table`
GROUP BY days_from_index
ORDER BY days_from_index;
```

## Sample trace

```sql
SELECT *
FROM `project.dataset.final_table`
WHERE business_key IN ('example_key_1', 'example_key_2', 'example_key_3')
ORDER BY business_key;
```
