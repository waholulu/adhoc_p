# Golden Dataset Guide

A golden dataset is a small known-answer dataset used to test whether an analysis pipeline handles important cases correctly.

## Include these cases

| Case type | Why it matters | Expected answer |
|---|---|---|
| Normal positive case | Confirms numerator inclusion | |
| Normal negative case | Confirms denominator only | |
| Excluded case | Confirms exclusion rule | |
| Boundary date case | Confirms inclusive or exclusive windows | |
| Duplicate case | Confirms deduplication | |
| Missing value case | Confirms missingness handling | |
| One-to-many join case | Confirms row multiplication prevention | |
| High-dollar case | Confirms financial totals | |
| Multiple-event case | Confirms index event selection | |
| Late-arriving data case | Confirms lag handling | |

## Minimum fields

- stable ID
- source values
- expected inclusion flag
- expected exclusion reason
- expected numerator flag
- expected denominator flag
- expected derived dates
- expected metric contribution
- expected group assignment

## Pass or fail rule

The implementation must exactly match expected flags and metric contributions for all golden dataset rows. Any mismatch requires explanation, a fix, or explicit business approval.

## How to use it

1. Create the small input tables or files.
2. Write expected outputs before running the implementation.
3. Run the generated analysis on the golden data.
4. Compare actual versus expected at row level.
5. Treat any mismatch as a blocker until explained.
