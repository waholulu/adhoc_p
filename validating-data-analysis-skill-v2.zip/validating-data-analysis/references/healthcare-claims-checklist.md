# Healthcare Claims and Clinical Analytics Checklist

Use this when validating claims, enrollment, authorization, readmission, HHS, SNF, post-acute care, cost, utilization, or clinical operations analyses.

## Core grain questions

- Is the grain member, member-month, claim, claim line, admission, discharge, authorization, provider, episode, facility, or day?
- Are inpatient stays deduplicated across claims and claim lines?
- Are transfers combined or treated as separate admissions?
- Are multiple discharges per member handled correctly?
- Are member IDs stable across eligibility, claims, auth, and care management systems?

## Enrollment and eligibility

Check:

- continuous enrollment window
- medical and pharmacy benefit eligibility if relevant
- dual eligibility or carve-out issues
- plan or product changes
- retroactive eligibility changes
- hospice, maternity, newborn, or other exclusion groups if relevant

## Claims timing

Do not mix these dates without explicit reason:

- service date
- admission date
- discharge date
- paid date
- received date
- processed date
- file load date

For recent periods, check claim lag before interpreting trend changes.

## Readmission analyses

Check:

- index admission definition
- planned readmission exclusions
- transfer handling
- same-day readmission handling
- 30-day window inclusivity
- member death or disenrollment after discharge
- readmission facility and service category logic
- numerator and denominator separately

## HHS, SNF, and post-acute care analyses

Check:

- discharge date used as index date
- HHS start date versus claim paid date
- 48-hour or other post-discharge window inclusivity
- SNF authorization versus actual SNF utilization
- prior authorization approval versus service received
- overlapping HHS and SNF episodes
- provider type and place-of-service logic
- DME and therapy claims not accidentally counted as HHS unless intended

## Cost and utilization analyses

Check:

- allowed amount versus paid amount versus billed amount
- claim reversals and adjustments
- outliers and winsorization rules
- per member, per discharge, or per member-month denominator
- pre/post windows
- claim lag and runout period
- whether pharmacy, behavioral health, and carved-out services are included

## Care management and operational data

Check:

- intervention timestamp versus documentation timestamp
- whether care management notes are available before the decision point
- whether future information leaked into the model or analysis
- referral status versus completed intervention
- unreachable members and failed outreach handling

## Causal or treatment effect claims

For causal language, require extra caution:

- treatment timing must be after eligibility for treatment and before outcome
- baseline covariates must be measured before treatment
- avoid conditioning on post-treatment variables
- check confounding by indication
- compare treated and untreated baseline risk
- use sensitivity checks, matching, weighting, doubly robust methods, or quasi-experimental design when appropriate
- avoid saying an intervention caused savings unless design supports causality
