# Analysis Contract Template

Use this before validating a data science or analytics result.

## Business framing

- Business question:
- Decision this result supports:
- Audience:
- Risk level:
- Expected output:
- What would change if the result is wrong:

## Data sources

| Source | Table or file | Refresh or extract date | Date range | Key fields | Notes |
|---|---|---|---|---|---|
| | | | | | |

## Cohort

- Unit of analysis:
- Inclusion criteria:
- Exclusion criteria:
- Required continuous eligibility or coverage window:
- Index event:
- Index date field:
- Follow-up window:
- Deduplication rule:
- Multiple-event handling rule:

## Metrics

| Metric | Numerator | Denominator | Time window | Grain | Expected range or benchmark |
|---|---|---|---|---|---|
| | | | | | |

## Validation plan

- Source checks:
- Grain checks:
- Join checks:
- Date checks:
- Sample trace checks:
- Reconciliation anchor:
- Golden dataset needed: Yes / No
- Independent reproduction needed: Yes / No

## Assumptions and risks

- Assumption:
- Known limitation:
- Data lag risk:
- Join risk:
- Missingness risk:
- Date logic risk:
- Business interpretation risk:
