---
name: validating-data-analysis
description: Audit and validate data science or analytics outputs for trustworthiness. Use when the user asks to verify, check, audit, vet, or sign off on a metric, SQL/Python/pandas/BigQuery result, dashboard, chart, cohort, model output, vibe-coded analysis, or AI-generated data result. Focus on source lineage, analysis contract, grain, joins, numerator and denominator, date logic, reconciliation, sample tracing, golden tests, and independent reproduction. Do not use for ordinary coding unless validation or trustworthiness is the task.
---

# Validating Data Analysis

## Purpose

Use this skill to validate data science and analytics outputs, especially AI-generated or vibe-coded work. The priority is not reading every line of implementation. The priority is deciding whether the result is trustworthy enough for the decision it supports.

Do not claim a result is guaranteed correct. Return one of three verdicts: Usable, Usable with caveats, or Not usable yet.

## Core rule

Validate observable evidence, not vibes.

A result is not trustworthy only because:

- the code ran
- the chart looks plausible
- the model gave a confident explanation
- a notebook completed without errors
- another AI agreed with the answer

A result becomes more trustworthy when there is independent evidence from:

- source lineage
- metric definitions
- cohort and grain checks
- row count and distinct key checks
- join cardinality checks
- numerator and denominator checks
- date boundary checks
- sample-level traces
- aggregate reconciliation
- golden dataset tests
- independent reproduction for high-stakes work

## When the user says not to review code

Respect the constraint. Do not depend on line-by-line code review. Validate from artifacts, data profiles, independent SQL, sample traces, known-answer tests, and reconciliation.

If the available evidence is insufficient, say so directly. Do not silently compensate by trusting the generated code.

## Risk levels

Classify the work before choosing validation depth.

| Risk level | Examples | Minimum validation |
|---|---|---|
| Exploratory | EDA, early hypothesis, personal scratch analysis | Source, contract, grain, denominator, row counts, a few sample checks |
| Business reporting | Shared dashboard, manager or director-facing metric, recurring report | Add join cardinality, date logic, reconciliation, repeatability, edge cases |
| High stakes | Clinical, financial, regulatory, client-facing, model deployment, policy or operations decision | Add golden dataset, independent reproduction, sensitivity checks, sign-off criteria |

## Default workflow

### 1. Reconstruct the analysis contract

Before validating outputs, identify:

- business question
- decision supported by the result
- intended audience
- source tables or files
- extract date or refresh date
- source date range
- unit of analysis
- cohort definition
- inclusion criteria
- exclusion criteria
- date fields used
- time window
- numerator
- denominator
- grouping dimensions
- expected range or benchmark
- assumptions and limitations

If any item is missing, continue with best effort and mark it as a validation gap.

### 2. Validate the denominator before the result

For rates, ratios, model scores, cost comparisons, and outcome analyses, validate the population first.

Never validate only the final percentage or chart. Always ask for or compute:

- denominator count
- numerator count
- excluded count by reason
- missing key fields
- duplicate keys
- date range
- distinct entity count at the intended grain

### 3. Check grain and join safety

Identify the intended grain, such as member, member-month, claim, claim line, admission, discharge, authorization, provider, episode, facility, or day.

Then compare:

- rows before and after each major join
- distinct primary keys before and after each major join
- unmatched left-side keys
- duplicated left-side keys after join
- sums of important dollar or utilization fields before and after join

Flag unexplained row multiplication, denominator shifts, or dollar inflation.

### 4. Check date logic

List every important date field and what it means. Common examples include service date, admit date, discharge date, event date, authorization start date, paid date, received date, load date, and eligibility month.

Test boundary cases such as:

- exactly on the index date
- exactly one day after index
- exactly two days after index
- exactly thirty days after index
- before the index event
- after the allowed window
- missing date
- overlapping dates

### 5. Trace sample records

For important analyses, trace at least these cases from source to final output:

1. normal included case
2. normal excluded case
3. boundary date case
4. high-dollar or high-impact case
5. case that contradicts the main conclusion
6. missing data case if relevant
7. duplicate or multi-event case if relevant

For each sample, show source fields, derived fields, final classification, and reason.

### 6. Reconcile aggregates

Compare the result with at least one independent anchor:

- source system total
- official dashboard
- prior production report
- finance or actuarial total
- published benchmark
- previous run
- simple independent SQL query
- manual spreadsheet calculation

A mismatch is not automatically fatal, but it must be explained.

### 7. Require golden tests for recurring or high-stakes work

For recurring or high-stakes analyses, require a small known-answer dataset that includes normal, negative, excluded, duplicate, missing, boundary, one-to-many join, and high-dollar cases.

Any implementation change must pass the golden dataset before the result is trusted.

### 8. Require independent reproduction for high-stakes work

For high-stakes work, the core result should be independently reproduced using one of:

- simplified SQL for the main numerator and denominator
- separate Python notebook from exported intermediate files
- spreadsheet replication for a small sample
- second analyst implementation from the analysis contract
- second AI implementation, only as supporting evidence

A second AI answer is useful, but it is not enough by itself.

## Verdict rules

### Mark as Not usable yet if any of these are true

- source tables or files are unknown
- unit of analysis is unclear
- denominator cannot be reproduced
- numerator and denominator are not separately available
- row counts change unexpectedly after joins
- dollar or utilization totals inflate after joins without explanation
- date field definitions are unclear
- sample cases fail manual trace
- reconciliation mismatch is large and unexplained
- high-stakes result has no independent reproduction or golden dataset evidence

### Mark as Usable with caveats if

- core denominator and numerator are reproducible
- no material join or date logic errors are found
- reconciliation is close or differences are explained
- limitations are documented
- remaining uncertainty is unlikely to change the decision

### Mark as Usable only if

- the analysis contract is complete
- all critical checks pass
- sample cases trace correctly
- reconciliation is acceptable
- assumptions are documented
- high-stakes work has independent reproduction or golden dataset evidence

## Response format

Use this structure when validating a result:

```markdown
# Validation verdict

Verdict: Usable / Usable with caveats / Not usable yet
Risk level: Exploratory / Business reporting / High stakes
Confidence: Low / Medium / High

## What I validated

- Business question:
- Output reviewed:
- Unit of analysis:
- Data sources:
- Date range:
- Metric definition:

## Main findings

1. Finding:
   Evidence:
   Severity: Low / Medium / High / Blocker
   Action:

## Validation checks

| Check | Status | Evidence | Issue | Action |
|---|---|---|---|---|
| Source freshness | Pass/Warn/Fail/Not checked | | | |
| Cohort definition | Pass/Warn/Fail/Not checked | | | |
| Grain | Pass/Warn/Fail/Not checked | | | |
| Join cardinality | Pass/Warn/Fail/Not checked | | | |
| Metric numerator | Pass/Warn/Fail/Not checked | | | |
| Metric denominator | Pass/Warn/Fail/Not checked | | | |
| Date logic | Pass/Warn/Fail/Not checked | | | |
| Missingness | Pass/Warn/Fail/Not checked | | | |
| Sample cases | Pass/Warn/Fail/Not checked | | | |
| Reconciliation | Pass/Warn/Fail/Not checked | | | |
| Sensitivity | Pass/Warn/Fail/Not checked | | | |
| Golden dataset | Pass/Warn/Fail/Not checked | | | |

## Minimum next actions

1. Action:
2. Action:
3. Action:

## Caveats

- Caveat:
```

## Supporting files

Use the bundled reference files when more detail is needed:

- `references/index.md`: which reference to open for each task
- `references/analysis-contract-template.md`: full analysis contract template
- `references/validation-report-template.md`: full validation report template
- `references/golden-dataset-guide.md`: known-answer dataset design
- `references/bigquery-validation-snippets.md`: BigQuery validation snippets
- `references/pandas-validation-snippets.md`: pandas validation snippets
- `references/healthcare-claims-checklist.md`: extra checks for claims, enrollment, readmission, HHS, SNF, auth, and cost analyses

## Behavior rules

- Be skeptical but practical.
- Prefer deterministic validation over verbal reassurance.
- Do not rubber stamp weak evidence.
- Focus on decision risk, not code aesthetics.
- Ask for missing artifacts only when necessary. Otherwise proceed with best effort and label gaps.
- When giving SQL or Python, make it validation code, not a hidden full reimplementation unless the user asks.
- Use project reference files for table names, metric definitions, and business rules when available.
- If reference files conflict with the generated result, flag the conflict and treat the reference file as the starting point until reconciled.
